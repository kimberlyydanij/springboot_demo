package backend_todolist.service;

import java.util.List;

import org.springframework.stereotype.Service;

import backend_todolist.dto.TodoDTO;

@Service
public interface TodoService {

	public List<TodoDTO> search() throws Exception;
	
	public int insert(TodoDTO dto) throws Exception;
	
	public int update(int id) throws Exception;
	
	public int delete(int id) throws Exception;
}
